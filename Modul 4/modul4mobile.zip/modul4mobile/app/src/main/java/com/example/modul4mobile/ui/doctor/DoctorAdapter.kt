package com.example.modul4mobile.ui.doctor

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.modul4mobile.Jobs
import com.example.modul4mobile.JobsDetail
import com.example.modul4mobile.JobsViewModel
import com.example.modul4mobile.R

class DoctorAdapter (

    private val context: Context,
    private val dataset: List<Jobs>
    ): RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> (){

    private val viewModel = JobsViewModel()
    class DoctorViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val doctorImg: ImageView = view.findViewById(R.id.jobs_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_jobs,parent,false)
        return DoctorViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val doctorData = dataset[position]
        holder.doctorImg.setImageResource(doctorData.imageResourceId)

        holder.itemView.setOnClickListener {
            viewModel.setJobs(doctorData, context)

            val intent = Intent(context, JobsDetail::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }
}