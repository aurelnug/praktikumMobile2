package com.example.modul4mobile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.modul4mobile.databinding.ActivityJobsDetailBinding

class JobsDetail : AppCompatActivity() {
    private var _binding: ActivityJobsDetailBinding? = null
    private val binding get() = _binding!!

    companion object {
        const val EXTRA_IMAGE = "image"
        const val EXTRA_NAME ="name"
        const val EXTRA_DESCRIPTION = "description"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityJobsDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val img = binding.imgDetail
        img.setImageResource(intent.getIntExtra(EXTRA_IMAGE, 0))

        val name = binding.tvName
        name.text = intent?.getStringExtra(EXTRA_NAME).toString()

        val desc = binding.tvDesc
        desc.text= intent?.getStringExtra(EXTRA_DESCRIPTION).toString()

    }
}