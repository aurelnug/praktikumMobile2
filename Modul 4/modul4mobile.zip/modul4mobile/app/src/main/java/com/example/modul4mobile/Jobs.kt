package com.example.modul4mobile

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Jobs(
    @DrawableRes val imageResourceId: Int,
    @StringRes val name: Int,
    @StringRes val desc: Int
)