package com.example.modul4mobile

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class JobsViewModel: ViewModel() {
    private val _name = MutableLiveData<String>()
    val name: LiveData<String>
    get() = _name

    private val _desc = MutableLiveData<String>()
    val desc: LiveData<String>
    get() = _desc

    private val _img = MutableLiveData<String>()
    val img: LiveData<String>
    get() = _img

    fun setJobs(jobs: Jobs, context: Context){
        _name.value = context.resources.getString(jobs.name)
        _desc.value = context.resources.getString(jobs.desc)
        _img.value = jobs.imageResourceId.toString()
    }
}