package com.example.modul4mobile.ui.doctor

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.modul4mobile.Jobs
import com.example.modul4mobile.JobsDetail
import com.example.modul4mobile.JobsViewModel
import com.example.modul4mobile.R

class AthleteAdapter (

    private val context: Context,
    private val dataset: List<Jobs>
): RecyclerView.Adapter<AthleteAdapter.AthleteViewHolder> (){

    private val viewModel = JobsViewModel()
    class AthleteViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val athleteImg: ImageView = view.findViewById(R.id.jobs_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AthleteViewHolder {
        val layout = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.fragment_jobs,parent,false)
        return AthleteViewHolder(layout)
    }

    override fun getItemCount() = dataset.size

    override fun onBindViewHolder(holder: AthleteViewHolder, position: Int) {
        val athleteData = dataset[position]
        holder.athleteImg.setImageResource(athleteData.imageResourceId)

        holder.itemView.setOnClickListener {
            viewModel.setJobs(athleteData, context)

            val intent = Intent(context, JobsDetail::class.java). apply {
                putExtra("name", viewModel.name.value)
                putExtra("description", viewModel.desc.value)
                putExtra("image", viewModel.img.value)
            }
            context.startActivity(intent)
        }
    }
}