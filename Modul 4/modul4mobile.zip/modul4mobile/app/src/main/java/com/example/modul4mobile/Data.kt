package com.example.modul4mobile

import androidx.lifecycle.ViewModel

class Data: ViewModel() {
    fun loadJobs(): List<Jobs>{
        return listOf(
            Jobs(
                R.drawable.doc1, R.string.doc1, R.string.desc1),
            Jobs(
                R.drawable.doc2, R.string.doc2, R.string.desc2),
            Jobs(
                R.drawable.doc3, R.string.doc3, R.string.desc3),
            Jobs(
                R.drawable.doc4, R.string.doc4, R.string.desc4),
            Jobs(
                R.drawable.doc5, R.string.doc5, R.string.desc5),
            Jobs(
                R.drawable.atlet1, R.string.athlete1, R.string.desc6),
            Jobs(
                R.drawable.atlet2, R.string.athlete2, R.string.desc7),
            Jobs(
                R.drawable.atlet3, R.string.athlete3, R.string.desc8),
            Jobs(
                R.drawable.atlet4, R.string.athlete4, R.string.desc9),
            Jobs(
                R.drawable.atlet5, R.string.athlete5, R.string.desc10)
        )
    }
}