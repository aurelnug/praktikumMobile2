package com.example.tiptime

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tiptime.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.koversi.setOnClickListener {
            calculateTip()
        }
    }

    fun calculateTip() {
        val stringInTextField = binding.nilaiMataUang.text.toString()
        val nilaiMataUang = stringInTextField.toDouble()
        val selectedId = binding.konvOptions.checkedRadioButtonId
        val tipPercentage = when (selectedId) {
            R.id.eur -> 0.20
            R.id.usd -> 0.18
            R.id.jpy -> 0.15
            R.id.sar -> 0.05
        }

        val indonesianLocale = Locale("in", "ID")
        val formattedTip = NumberFormat.getCurrencyInstance(indonesianLocale).format(nilaiMataUang)


        var tip = tipPercentage * nilaiMataUang
        binding.hasil.text = getString(R.string.hasil)
    }
}